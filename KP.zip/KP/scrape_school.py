import os
import csv
import time
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from urllib.parse import urljoin, urlparse

# === KONFIGURASI ===
BASE_URL = "https://sdnbandarharjo01.dikdas.semarangkota.go.id/"
OUTPUT_DIR = "hasil"
os.makedirs(f"{OUTPUT_DIR}/html", exist_ok=True)
os.makedirs(f"{OUTPUT_DIR}/images", exist_ok=True)
os.makedirs(f"{OUTPUT_DIR}/css", exist_ok=True)
os.makedirs(f"{OUTPUT_DIR}/js", exist_ok=True)

# === SETUP SELENIUM ===
chrome_service = Service("C:/Users/NHQE1/OneDrive/Documents/KP/chromedriver-win64/chromedriver.exe")
chrome_options = Options()
chrome_options.add_argument("--headless")  # jalan tanpa buka browser
driver = webdriver.Chrome(service=chrome_service, options=chrome_options)

# === FUNGSI ===
def download_file(url, folder):
    try:
        filename = os.path.basename(urlparse(url).path)
        filepath = os.path.join(OUTPUT_DIR, folder, filename)
        if not filename:
            return
        r = requests.get(url, timeout=10)
        if r.status_code == 200:
            with open(filepath, "wb") as f:
                f.write(r.content)
    except Exception as e:
        print(f"[!] Gagal download {url}: {e}")

def scrape_page(url):
    print(f"[>] Scraping: {url}")
    driver.get(url)
    time.sleep(2)
    html = driver.page_source
    soup = BeautifulSoup(html, "html.parser")

    # Simpan HTML mentahan
    filename = urlparse(url).path.strip("/").replace("/", "_") or "index"
    with open(f"{OUTPUT_DIR}/html/{filename}.html", "w", encoding="utf-8") as f:
        f.write(soup.prettify())

    # Ambil semua gambar, css, js
    for img in soup.find_all("img", src=True):
        img_url = urljoin(url, img["src"])
        download_file(img_url, "images")

    for css in soup.find_all("link", href=True):
        if "stylesheet" in css.get("rel", []):
            css_url = urljoin(url, css["href"])
            download_file(css_url, "css")

    for script in soup.find_all("script", src=True):
        js_url = urljoin(url, script["src"])
        download_file(js_url, "js")

    # Ambil semua link internal untuk diikuti nanti
    internal_links = set()
    for a in soup.find_all("a", href=True):
        link = urljoin(url, a["href"])
        if BASE_URL in link:
            internal_links.add(link)
    return internal_links

# === PROSES UTAMA ===
to_visit = {BASE_URL}
visited = set()
all_data = []

while to_visit:
    current = to_visit.pop()
    if current in visited:
        continue
    visited.add(current)

    new_links = scrape_page(current)
    to_visit.update(new_links - visited)
    all_data.append([current])

# === SIMPAN KE CSV ===
with open(f"{OUTPUT_DIR}/hasil.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["URL"])
    writer.writerows(all_data)

driver.quit()
print("[+] Selesai! Semua halaman dan resource sudah disimpan di folder 'hasil/'")
